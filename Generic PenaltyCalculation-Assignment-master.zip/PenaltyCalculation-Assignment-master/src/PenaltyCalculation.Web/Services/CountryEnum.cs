﻿namespace PenaltyCalculation.Web.Services
{
    public enum CountryEnum
    {
       TR=1,
       AE=2
    }
}
